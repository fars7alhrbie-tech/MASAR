# MASAR | مَسَار
إرشاد وصول الحجاج إلى مطار الملك عبدالعزيز (جدة). بلا تسجيل دخول وبلا بيانات شخصية.

## التشغيل
1. `npm install`
2. `cp .env.example .env.local` ثم ضع `FR24_API_TOKEN` (اشتراك API رسمي من fr24api.flightradar24.com).
3. `npm run dev`

## الفحوصات
`npm run typecheck && npm run lint && npm test && npm run build`

## النشر على Vercel
استورد المستودع، وأضف `FR24_API_TOKEN` (و`NEXT_PUBLIC_CAMPAIGN_CONTACT_URL` اختياريًا) في Environment Variables.

## قرارات وحدود
- لا Prisma/PostgreSQL: لا توجد بيانات دائمة حاليًا. تُضاف عند ظهور حاجة فعلية (مثل بلاغات).
- لا تُعرض بوابات/سيور/حافلات لأنه لا يوجد مصدر مخوّل لها.
- التحديد المعدّل والتخزين المؤقت في الذاكرة (لكل نسخة خادم)؛ للإنتاج متعدد النسخ استخدم مخزنًا مشتركًا.
- تحقق من أسماء حقول وشروط خطة Flightradar24 (مثل `eta`) مع حسابك قبل الاعتماد عليها.
