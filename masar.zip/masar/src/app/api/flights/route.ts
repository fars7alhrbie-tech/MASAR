import { NextRequest, NextResponse } from "next/server";
import { flightNumberSchema, lookupFlight } from "@/lib/fr24";
const hits = new Map<string, number[]>();
function limited(ip: string) { const now = Date.now(); const a = (hits.get(ip) ?? []).filter(x => now - x < 60_000); a.push(now); hits.set(ip, a); return a.length > 20; }
export async function GET(req: NextRequest) {
 const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
 if (limited(ip)) return NextResponse.json({ status: "rate_limited" }, { status: 429 });
 const p = flightNumberSchema.safeParse(req.nextUrl.searchParams.get("number") ?? "");
 if (!p.success) return NextResponse.json({ status: "invalid" }, { status: 400 });
 const r = await lookupFlight(p.data);
 const code = r.status === "ok" ? 200 : r.status === "not_found" ? 404 : r.status === "unconfigured" ? 503 : 502;
 return NextResponse.json(r, { status: code, headers: { "Cache-Control": "no-store" } });
}
