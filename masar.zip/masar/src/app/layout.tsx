import "./globals.css";
export const metadata = { title: "MASAR | مَسَار" };
export default function L({ children }: { children: React.ReactNode }) {
 return <html lang="ar" dir="rtl"><body className="bg-white text-masar-green text-lg font-sans">{children}</body></html>;
}
