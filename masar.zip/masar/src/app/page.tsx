"use client";
import { useEffect, useState } from "react";
import { dict, Lang } from "@/lib/i18n";
type R = { status: string; flight?: string; eta?: string; arrivesAtJED?: boolean; updatedAt?: string; source?: string };
export default function Home() {
 const [lang, setLang] = useState<Lang>("ar"); const [n, setN] = useState(""); const [r, setR] = useState<R | null>(null); const [busy, setBusy] = useState(false);
 const t = dict[lang];
 useEffect(() => { try { const s = localStorage.getItem("masar-lang"); if (s === "en" || s === "ar") setLang(s); } catch {} }, []);
 useEffect(() => { document.documentElement.lang = lang; document.documentElement.dir = lang === "ar" ? "rtl" : "ltr"; try { localStorage.setItem("masar-lang", lang); } catch {} }, [lang]);
 async function go(e: React.FormEvent) { e.preventDefault(); setBusy(true); try { const res = await fetch(`/api/flights?number=${encodeURIComponent(n)}`); setR(await res.json()); } catch { setR({ status: "provider_error" }); } setBusy(false); }
 const contact = process.env.NEXT_PUBLIC_CAMPAIGN_CONTACT_URL;
 const errs = t.err as Record<string, string>;
 return (<main className="mx-auto max-w-2xl p-4 space-y-6">
  <header className="bg-masar-green text-white rounded-2xl p-5 border-b-4 border-masar-gold">
   <div className="flex justify-between items-center"><h1 className="text-3xl font-bold">{t.title}</h1>
    <button className="min-h-12 px-4 rounded-xl bg-masar-gold text-masar-green font-bold" onClick={() => setLang(lang === "ar" ? "en" : "ar")} aria-label="Language / اللغة">{lang === "ar" ? "English" : "العربية"}</button></div>
   <p className="mt-2">{t.sub}</p></header>
  <form onSubmit={go} className="space-y-3"><label htmlFor="f" className="block font-bold">{t.flight}</label>
   <input id="f" dir="ltr" value={n} onChange={e => setN(e.target.value)} maxLength={8} autoComplete="off" className="w-full min-h-14 border-2 border-masar-green rounded-xl px-4 text-xl" placeholder="SV123" />
   <button disabled={busy} className="w-full min-h-14 rounded-xl bg-masar-green text-white font-bold text-xl">{t.search}</button></form>
  <div aria-live="polite">{r && (r.status === "ok" ? (<div className="border-2 border-masar-green rounded-2xl p-4">
    <p dir="ltr" className="font-bold text-2xl">{r.flight}</p>
    {!r.arrivesAtJED && <p>{t.notJED}</p>}
    {r.eta && <p>ETA: <bdi dir="ltr">{r.eta}</bdi></p>}
    <p className="text-base">{t.updated}: <bdi dir="ltr">{r.updatedAt}</bdi> · {t.source}: {r.source}</p></div>)
   : <p role="alert" className="border-2 border-red-700 text-red-900 rounded-2xl p-4">{errs[r.status] ?? errs.provider_error}</p>)}</div>
  <ol className="space-y-3">{t.steps.map((s, i) => <li key={i} className="flex gap-3 items-center border-2 border-masar-green rounded-2xl p-4"><span className="bg-masar-gold text-masar-green font-bold rounded-full w-10 h-10 grid place-items-center">{i + 1}</span>{s}</li>)}</ol>
  <p className="text-base">{t.stepNote}</p>
  <section aria-labelledby="h" className="border-4 border-masar-gold rounded-2xl p-4"><h2 id="h" className="text-2xl font-bold">{t.help}</h2>
   {contact ? <a href={contact} className="mt-3 block text-center min-h-14 leading-[3.5rem] rounded-xl bg-masar-green text-white font-bold">{t.helpBtn}</a> : <p className="mt-2">{t.helpNone}</p>}</section>
 </main>);
}
