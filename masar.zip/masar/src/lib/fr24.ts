import { z } from "zod";
export const flightNumberSchema = z.string().trim().toUpperCase().regex(/^[A-Z0-9]{2,3}\d{1,4}[A-Z]?$/);
export type FlightResult =
 | { status: "ok"; flight: string; origin?: string; destination?: string; eta?: string; arrivesAtJED: boolean; updatedAt: string; source: "Flightradar24" }
 | { status: "not_found" | "unconfigured" | "forbidden" | "rate_limited" | "provider_error" | "timeout" };
const BASE = "https://fr24api.flightradar24.com";
const cache = new Map<string, { at: number; v: FlightResult }>();
const TTL = 60_000;
export async function lookupFlight(raw: string, f: typeof fetch = fetch): Promise<FlightResult> {
 const n = flightNumberSchema.parse(raw);
 const token = process.env.FR24_API_TOKEN;
 if (!token) return { status: "unconfigured" };
 const hit = cache.get(n);
 if (hit && Date.now() - hit.at < TTL) return hit.v;
 const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 8000);
 try {
  const r = await f(`${BASE}/api/live/flight-positions/light?flights=${encodeURIComponent(n)}`, {
   headers: { Authorization: `Bearer ${token}`, Accept: "application/json", "Accept-Version": "v1" }, signal: ctl.signal });
  if (r.status === 401 || r.status === 403) return { status: "forbidden" };
  if (r.status === 429) return { status: "rate_limited" };
  if (!r.ok) return { status: "provider_error" };
  const body = (await r.json()) as { data?: Array<Record<string, unknown>> };
  const d = body.data?.[0];
  const v: FlightResult = !d ? { status: "not_found" } : {
   status: "ok", flight: n, source: "Flightradar24", updatedAt: new Date().toISOString(),
   origin: typeof d.orig_iata === "string" ? d.orig_iata : undefined,
   destination: typeof d.dest_iata === "string" ? d.dest_iata : undefined,
   eta: typeof d.eta === "string" ? d.eta : undefined,
   arrivesAtJED: d.dest_iata === "JED" };
  cache.set(n, { at: Date.now(), v }); return v;
 } catch (e) { return { status: (e as Error).name === "AbortError" ? "timeout" : "provider_error" }; }
 finally { clearTimeout(t); }
}
export const _clearCache = () => cache.clear();
