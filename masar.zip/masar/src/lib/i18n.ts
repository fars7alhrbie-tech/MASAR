export type Lang = "ar" | "en";
export const dict = {
 ar: { title: "مَسَار", sub: "إرشاد وصول الحجاج – مطار الملك عبدالعزيز، جدة", flight: "رقم الرحلة", search: "ابحث", steps: ["الهجرة والجوازات","استلام الأمتعة","مقابلة ممثل الحملة","ركوب الحافلة"],
  stepNote: "تفاصيل البوابات والسيور والحافلات غير متاحة حاليًا. اتبع اللوحات الإرشادية وتعليمات ممثل الحملة.",
  help: "أحتاج إلى مساعدة", helpNone: "لم تُهيّأ وسيلة تواصل إلكترونية بعد. توجّه إلى أقرب موظف أو ممثل الحملة في المطار.", helpBtn: "تواصل مع الحملة",
  updated: "آخر تحديث", source: "المصدر", notJED: "هذه الرحلة لا تتجه إلى جدة وفق البيانات المتاحة.",
  err: { invalid: "رقم الرحلة غير صالح. مثال: SV123", not_found: "لم نجد هذه الرحلة. قد لا تكون البيانات متاحة بعد.", unconfigured: "بيانات الرحلات الحية غير مفعّلة (مفتاح المزود غير مهيأ).", forbidden: "صلاحية مزود البيانات لا تسمح بهذا الطلب.", rate_limited: "طلبات كثيرة. حاول بعد قليل.", provider_error: "تعذّر الوصول إلى مزود البيانات.", timeout: "انتهت مهلة الطلب. حاول مجددًا." } },
 en: { title: "MASAR", sub: "Hajj arrival guidance – King Abdulaziz Airport, Jeddah", flight: "Flight number", search: "Search", steps: ["Immigration & passports","Baggage claim","Meet your group representative","Board the bus"],
  stepNote: "Gate, belt and bus details are not available yet. Follow airport signs and your group representative's instructions.",
  help: "I need help", helpNone: "No online contact is configured yet. Ask the nearest staff member or your group representative at the airport.", helpBtn: "Contact the group",
  updated: "Last updated", source: "Source", notJED: "Per available data, this flight is not headed to Jeddah.",
  err: { invalid: "Invalid flight number. Example: SV123", not_found: "Flight not found. Data may not be available yet.", unconfigured: "Live flight data is not enabled (provider key not configured).", forbidden: "The data provider plan does not allow this request.", rate_limited: "Too many requests. Try again shortly.", provider_error: "Could not reach the data provider.", timeout: "Request timed out. Try again." } },
} as const;
