export default {content:["./src/**/*.{ts,tsx}"],theme:{extend:{colors:{masar:{green:"#0b3d2e",gold:"#c9a227"}}}}};
