import { describe, it, expect, beforeEach, vi } from "vitest";
import { lookupFlight, flightNumberSchema, _clearCache } from "../src/lib/fr24";
const mk = (s: number, b: unknown = {}) => vi.fn(async () => new Response(JSON.stringify(b), { status: s })) as unknown as typeof fetch;
beforeEach(() => { _clearCache(); process.env.FR24_API_TOKEN = "t"; });
describe("fr24", () => {
 it("rejects malicious input", () => { for (const x of ["../x", "SV123;DROP", "<script>", ""]) expect(flightNumberSchema.safeParse(x).success).toBe(false); });
 it("no key -> unconfigured, no fetch", async () => { delete process.env.FR24_API_TOKEN; const f = mk(200); expect((await lookupFlight("SV123", f)).status).toBe("unconfigured"); expect(f).not.toHaveBeenCalled(); });
 it("not found", async () => expect((await lookupFlight("SV123", mk(200, { data: [] }))).status).toBe("not_found"));
 it("provider down", async () => expect((await lookupFlight("SV123", mk(500))).status).toBe("provider_error"));
 it("rate limited", async () => expect((await lookupFlight("SV123", mk(429))).status).toBe("rate_limited"));
 it("ok has updatedAt, no gate data", async () => { const r = await lookupFlight("SV123", mk(200, { data: [{ dest_iata: "JED" }] })); expect(r).toMatchObject({ status: "ok", arrivesAtJED: true, source: "Flightradar24" }); expect(Object.keys(r)).not.toContain("gate"); });
});
